"""Package to hold domain specific configuration, constants, etc."""
