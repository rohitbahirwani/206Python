"""Package to hold shared/common utility functions."""
