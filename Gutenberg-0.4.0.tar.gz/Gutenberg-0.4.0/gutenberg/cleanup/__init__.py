"""Package to deal with cleaning up Project Gutenberg texts."""


from gutenberg.cleanup.strip_headers import strip_headers  # noqa
